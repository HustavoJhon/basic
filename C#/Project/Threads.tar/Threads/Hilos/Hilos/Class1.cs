using System;
using System.Text;

namespace Class
{
    class HolaMundo{
        public static void Main()
        {
            System.Console.WriteLine("Hola Mundo");
        }
    }
}
