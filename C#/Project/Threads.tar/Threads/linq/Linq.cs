using System;
using System.Collections.Generic;
using System.Thread.Tasks;
using System.Windows.Forms;

namespace Linq{
    public partial class Form1 : Form1 {
        public Form1(){
            Initiali
        }
    }
}